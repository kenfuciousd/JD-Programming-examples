Credit: Molly "Cougarmint" Willits
Created by hand using Microsoft Paint and Photoshop Educational Edition 6.0.

Licences:
Slot Machine Symbols: CC-BY 3.0, CC-BY-SA 3.0.
Bare Bones Slot Machine Graphics: Public Domain

Free Commercial Use: Yes
Free Personal Use: Yes

Included in this Pack:

Bar1.png
Bar2.png
Bar3.png
bell.png
cherries.png
clover.png
heart.png
horseshoe.png
lemon.png
lucky7_rainbow.png
melon.png

Barebones Slot Machine Folder:
bet.png
bet_pressed.png
paylineframe.png
SMFrame_blank.png
SMFrame_demo.png
SMFrame_withguide.png
spin.ping
spin_pressed.ping

Demo Graphics Folder:
slotsymbolsheet.png
SMFrame_demo2.png

Variations Folder:
heart_outline.png
heart_rainbow.png
lucky7.png

Donations: Not needed, but appreciated. Contact me if you'd like to make a donation.